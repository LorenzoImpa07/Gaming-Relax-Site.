# Gaming Relax — Sito Web

Sito statico (HTML/CSS/JS puro, nessuna build richiesta) per **Gaming Relax**, attività di tastiere custom, keycaps artisan e servizi digitali (bot Discord, consulenze, grafica).

Ricreato a partire da una registrazione video del sito originale (site123.me), con la stessa struttura di pagine, testi e identità visiva (tema scuro, accento verde lime + viola).

## Struttura del progetto

```
gaming-relax/
├── index.html        Home
├── store.html         Store (prodotti)
├── custom.html        Percorso "crea la tua tastiera custom"
├── art.html           Galleria opere / keycaps artisan
├── team.html          Il team
├── contatti.html       Form contatti
├── faq.html           Domande frequenti
├── privacy.html        Privacy Policy
├── termini.html        Termini e Condizioni
├── css/
│   └── style.css      Tutti gli stili del sito
└── js/
    └── script.js       Menu mobile, FAQ accordion, filtri, form
```

## Come pubblicarlo su GitHub Pages

1. Crea un nuovo repository su GitHub (es. `gaming-relax`).
2. Carica tutti i file di questa cartella nella root del repository.
3. Vai su **Settings → Pages**.
4. In "Source" seleziona il branch `main` e la cartella `/ (root)`.
5. Salva: dopo qualche minuto il sito sarà online su `https://<tuo-utente>.github.io/gaming-relax/`.

## Cosa completare prima di andare online

Questo è un sito dimostrativo, pronto graficamente ma con alcuni contenuti segnaposto da sostituire:

- **Immagini reali**: logo, foto del team, foto prodotti e galleria Art (attualmente sono blocchi colorati/gradienti al posto delle foto).
- **Store**: collegare un vero sistema di pagamento (Stripe, PayPal, Shopify Buy Button…) — attualmente il bottone "Acquista" è solo un link segnaposto.
- **Form contatti** (`contatti.html`): al momento il form non invia dati da nessuna parte. Per farlo funzionare, collegalo a un servizio come [Formspree](https://formspree.io) o [EmailJS](https://www.emailjs.com), oppure a un tuo backend.
- **Link social**: sostituisci i link `#` di Discord, YouTube, Instagram, TikTok con quelli reali.
- **Team**: completa i profili "Da definire" nella pagina Team con nomi e foto reali.
- **Testi legali**: Privacy Policy e Termini sono indicativi — fatti revisionare da un professionista prima della pubblicazione.

## Personalizzazione rapida

- Colori: variabili CSS in cima a `css/style.css` (`--lime`, `--purple`, `--bg`…).
- Font: Space Grotesk (titoli) + Inter (testo), caricati da Google Fonts.
- Menu e footer sono ripetuti in ogni pagina HTML (sito statico semplice, senza componenti); se in futuro vuoi evitare di modificare ogni file singolarmente, valuta un framework come Astro o degli include lato build.
